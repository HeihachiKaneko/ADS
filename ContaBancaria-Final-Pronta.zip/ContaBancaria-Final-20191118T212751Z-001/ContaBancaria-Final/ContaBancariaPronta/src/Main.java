import interfaceGrafica.InterfaceGrafica;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceGrafica interfaceGrafica = new InterfaceGrafica();

		interfaceGrafica.cadastrarUsuario();

		
		//1- Maximo 1000 negativo
		//2- Criar somente uma lista de movimento e filtrar no momento de gerar o extrato todos/saque/deposito
	}

}
