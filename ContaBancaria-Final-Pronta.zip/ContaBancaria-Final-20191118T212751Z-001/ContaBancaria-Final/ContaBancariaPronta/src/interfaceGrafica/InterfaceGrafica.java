package interfaceGrafica;

import javax.swing.JOptionPane;

import conta.Conta;
import conta.Movimentacao;

public class InterfaceGrafica {

	Conta conta = new Conta();

	public void cadastrarUsuario() {
		String nomeUsuario = JOptionPane.showInputDialog("Informe seu nome:");
		conta.setTitularConta(nomeUsuario);
		int tipo = Integer.parseInt(JOptionPane
				.showInputDialog("Qual o tipo de conta ? \n" + "1 - Conta poupanca \n" + "2 - Conta corrente"));
		while (true) {
			switch (tipo) {
			case 1:
				conta.setTipo(tipo);
				exibirMenu(conta);
				break;
			case 2:
				conta.setTipo(tipo);
				exibirMenu(conta);
				break;
			default:
				JOptionPane.showMessageDialog(null, "Erro, tente uma op��o v�lida", "Erro", JOptionPane.ERROR_MESSAGE);
				tipo = Integer.parseInt(JOptionPane
						.showInputDialog("Qual o tipo de conta ? \n" + "1 - Conta poupanca \n" + "2 - Conta corrente"));
				break;
			}
		}
	}

	public void exibirMenu(Conta conta) {
		while (true) {
			int opcao = Integer.parseInt(JOptionPane.showInputDialog("Qual opcao bancaria deseja fazer "
					+ conta.getTitularConta() + "? \n" + "1 - Depositar  \n" + "2 - Sacar \n"
					+ "3 - Mostrar Saldo \n" + "4 - Mostrar dados da Conta \n" + "5 - Mostrar Extrato Completo \n"
					+ "6 - Mostrar Extrato Depositos \n" + "7 - Mostrar Extrato Saques \n" + "8 - Sair"));

			switch (opcao) {
			case 1:
				this.informacoesDeposito(conta);
				break;
			case 2:
				this.informacoesSaque(conta);
				break;
			case 3:
				this.mostrarSaldo(conta);
				break;
			case 4:
				this.mostrarDadosConta(conta);
				break;
			case 5:
				this.mostrarExtratoCompleto(conta);
				break;
			case 6:
				this.mostrarExtratoDesposito(conta);
				break;
			case 7:
				this.mostrarExtratoSaque(conta);
				break;
			case 8:
				System.exit(0);
			default:
				JOptionPane.showMessageDialog(null, "Erro, tente uma op��o v�lida", "Erro", JOptionPane.ERROR_MESSAGE);
				break;
			}
		}
	}

	public void informacoesDeposito(Conta conta) {
		float valor = Float.parseFloat(JOptionPane.showInputDialog("Insira o valor que deseja depositar:"));
		while (valor < 10) {
			JOptionPane.showMessageDialog(null, "O valor depositado n�o pode ser menor que R$ 10.00", "Erro",
					JOptionPane.ERROR_MESSAGE);
			valor = Float.parseFloat(JOptionPane.showInputDialog("Insira o valor que deseja depositar:"));
		}
		conta.depositar(valor);
	}

	public void informacoesSaque(Conta conta) {
		float valor = Float.parseFloat(JOptionPane.showInputDialog("Insira o valor que deseja sacar: "));
		while (valor < 5) {
			JOptionPane.showMessageDialog(null, "O valor depositado n�o pode ser menor que R$ 5.00", "Erro",
					JOptionPane.ERROR_MESSAGE);
			valor = Float.parseFloat(JOptionPane.showInputDialog("Insira o valor que deseja sacar:"));
		}
		
		while (conta.getSaldo() - valor < -1000) {
            JOptionPane.showMessageDialog(null, "Sua conta nao pode ficar em menos de R$ -1000.00 " + "\n" 
            		+ "Saldo atual: R$ " + conta.getSaldo(), "Erro", JOptionPane.ERROR_MESSAGE);
            valor = Float.parseFloat(JOptionPane.showInputDialog("Saldo atual: R$ " + conta.getSaldo() + "\n" + 
            		"Insira o valor em R$ a ser sacado"));
        }
		conta.sacar(valor);
	}

	public void mostrarSaldo(Conta conta) {
		String mostrarSaldo = "Saldo: R$ " + conta.getSaldo();
		JOptionPane.showMessageDialog(null, mostrarSaldo);
	}

	public void mostrarDadosConta(Conta conta) {
		String dados = "Nome do Titular: " + conta.getTitularConta() + "\n" + "Tipo de Conta: " + conta.getTipo() + "\n"
				+ "Saldo: R$ " + conta.getSaldo();
		JOptionPane.showMessageDialog(null, dados, "Dados da Conta", JOptionPane.INFORMATION_MESSAGE);
	}

	public void mostrarExtratoCompleto(Conta conta) {
		String movimentacoes = "";
		if (conta.getListaDeMovimentacoes().size() == 0) {
			movimentacoes = "Voc� ainda n�o possui movimenta��es em sua conta";
		} else {
			for (Movimentacao movimentacao : conta.getListaDeMovimentacoes()) {
				if (movimentacao.getTipo() == 2) {
					movimentacoes += movimentacao.getData() + " - Dep�sito de R$ " + movimentacao.getValor() + "\n";
				} else if(movimentacao.getTipo() == 1) {
					movimentacoes += movimentacao.getData() + " - Saque de R$ " + movimentacao.getValor() + "\n";
				}
			}
		}
		JOptionPane.showMessageDialog(null, movimentacoes, "Extrato Completo", JOptionPane.INFORMATION_MESSAGE);
	}

	public void mostrarExtratoDesposito(Conta conta) {
		String depositos = "";
		if (conta.getListaDeMovimentacoes().size() == 0) {
			depositos = "Voc� ainda n�o efetuou nenhum Deposito";
		} else {
			for (Movimentacao movimentacao : conta.getListaDeMovimentacoes()) {
				if (movimentacao.getTipo() == 2) {
					depositos += movimentacao.getData() + " - Dep�sito de R$ " + movimentacao.getValor() + "\n";
				}
			}
		}
		JOptionPane.showMessageDialog(null, depositos, "Extrato de Dep�sitos", JOptionPane.INFORMATION_MESSAGE);
	}

	public void mostrarExtratoSaque(Conta conta) {
		String saques = "";
		if (conta.getListaDeMovimentacoes().size() == 0) {
			saques = "Voc� ainda n�o efetuou nenhum saque";
		} else {
			for (Movimentacao movimentacao : conta.getListaDeMovimentacoes()) {
				if (movimentacao.getTipo() == 1) {
					saques += movimentacao.getData() + " - Saque de R$ " + movimentacao.getValor() + "\n";
				}
			}
		}
		JOptionPane.showMessageDialog(null, saques, "Extrato de Saques", JOptionPane.INFORMATION_MESSAGE);
	}

}
