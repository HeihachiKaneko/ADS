import view.InterfaceGrafica;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceGrafica interfaceGrafica = new InterfaceGrafica();

		interfaceGrafica.cadastrarUsuario();

	}

}
